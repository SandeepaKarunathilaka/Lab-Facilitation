const USER_ROLES = {
  PATIENT: "PATIENT",
  ADMIN: "ADMIN",
};

module.exports = USER_ROLES;
