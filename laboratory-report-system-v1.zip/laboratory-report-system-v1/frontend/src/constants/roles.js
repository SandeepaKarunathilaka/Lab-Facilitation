export const USER_ROLES = {
  PATIENT: "PATIENT",
  ADMIN: "ADMIN",
};
