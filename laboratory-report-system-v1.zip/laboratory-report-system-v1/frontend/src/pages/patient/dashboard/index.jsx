import PatientSidebar from "./PatientSidebar";
//
const index = () => {
  return (
    <>
      <PatientSidebar />
    </>
  );
};

export default index;
