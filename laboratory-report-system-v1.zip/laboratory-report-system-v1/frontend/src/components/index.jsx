import BootstrapModal from "./BootstrapModal";
import BootstrapTable from "./BootstrapTable";

export { BootstrapModal, BootstrapTable };
